import sqlite3
import tkinter as tk
import time
import datetime

def OpenAddSample2():
    conn = sqlite3.connect('test.db')
    conn.execute("PRAGMA foreign_keys = ON")
    c = conn.cursor()

    window_AddSample = tk.Tk()
    window_AddSample.title("ADD SAMPLE POSITION")

    #SETTING UP NEW Sample FORM----------------------------------------------------------------
    tk.Label(window_AddSample, text = "Sample ID").grid(row = 0)
    sampleID = tk.Entry(window_AddSample)
    sampleID.grid(row = 0, column = 1)

    tk.Label(window_AddSample, text = "Fridge ID").grid(row = 1)
    fridgeID = tk.Entry(window_AddSample)
    fridgeID.grid(row = 1, column = 1)

    tk.Label(window_AddSample, text = "Shelf Number").grid(row = 2)
    shelfNum = tk.Entry(window_AddSample)
    shelfNum.grid(row = 2, column = 1)

    tk.Label(window_AddSample, text = "Box Number").grid(row = 3)
    boxNum = tk.Entry(window_AddSample)
    boxNum.grid(row = 3, column = 1)

    tk.Label(window_AddSample, text = "X Position").grid(row = 4)
    xPos = tk.Entry(window_AddSample)
    xPos.grid(row = 4, column = 1)

    tk.Label(window_AddSample, text = "Y Position").grid(row = 5)
    yPos = tk.Entry(window_AddSample)
    yPos.grid(row = 5, column = 1)

    tk.Label(window_AddSample, text = "Z Position").grid(row = 6)
    zPos = tk.Entry(window_AddSample)
    zPos.grid(row = 6, column = 1)

    def data_newSample():
        c.execute("INSERT INTO samplePositionTable (sampleID, fridgeID, shelfNum, boxNum, xPos, yPos, zPos) VALUES (?, ?, ?, ?, ?, ?, ?)",
    (str(sampleID.get()), str(fridgeID.get()), int(shelfNum.get()), int(boxNum.get()), int(xPos.get()), int(yPos.get()), int(zPos.get())))
        conn.commit()


    tk.Button(window_AddSample, text = 'Populate', command = data_newSample).grid(row = 8, column=1)


    window_AddSample.mainloop()
    c.close()
    conn.close()
    #----------------------------------------------------------------------------------------

