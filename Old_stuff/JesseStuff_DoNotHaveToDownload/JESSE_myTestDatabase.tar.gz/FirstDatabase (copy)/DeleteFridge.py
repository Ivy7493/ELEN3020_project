import sqlite3
import tkinter as tk

def Open_DeleteFridge():
    conn = sqlite3.connect('test.db')
    conn.execute("PRAGMA foreign_keys = ON")
    c = conn.cursor()

    window_DeleteFridge = tk.Tk()
    window_DeleteFridge.title("DELETE FRIDGE")

    def deleteFridge():
        c.execute('DELETE FROM fridgeTable WHERE fridgeID = ?', (str(delFridgeID.get()),))
        conn.commit()

    #---------------------------------------------------------------------------------
    delFridgeID = tk.Entry(window_DeleteFridge)
    delFridgeID.grid(row=1,column=1)

    searchButton1 = tk.Button(window_DeleteFridge, text = 'Delete', command = deleteFridge).grid(row = 1, column = 2)
    #---------------------------------------------------------------------------------

    window_DeleteFridge.mainloop()
    c.close()
    conn.close()
