import sqlite3
import tkinter as tk
import AddSample
import AddSample2

conn = sqlite3.connect('test.db')
conn.execute("PRAGMA foreign_keys = ON")
c = conn.cursor()

#SETTING UP MAIN SCREEN----------------------------------------------------------------
window_Main = tk.Tk()

window_Main.title("MAIN SAMPLE WINDOW")
window_Main["bg"] = 'purple'

addButton = tk.Button(window_Main, text = 'Add Sample', command = AddSample.OpenAddSample).grid(row = 1, column = 1)

addButton2 = tk.Button(window_Main, text = 'Add Sample Position', command = AddSample2.OpenAddSample2).grid(row = 2, column = 1)

#searchButton = tk.Button(window_Main, text = 'Display all fridges', command = DisplayFridges.OpenAllFridges).grid(row = 2, column = 1)

#deleteButton = tk.Button(window_Main, text = 'Delete fridges', command = DeleteFridge.Open_DeleteFridge).grid(row = 3, column = 1)






window_Main.mainloop()
#----------------------------------------------------------------------------------------

c.close()
conn.close()

