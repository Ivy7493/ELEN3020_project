import sqlite3
import tkinter as tk

conn = sqlite3.connect('test.db')
conn.execute("PRAGMA foreign_keys = ON")
c = conn.cursor()

def create_fridgeTable():
    c.execute('CREATE TABLE IF NOT EXISTS fridgeTable(fridgeID TEXT PRIMARY KEY, temperature INTEGER, numShelves INTEGER, numBoxes INTEGER, boxX INTEGER, boxY INTEGER, boxZ INTEGER)')

    c.execute('CREATE UNIQUE INDEX IF NOT EXISTS indexFridgeID ON fridgeTable(fridgeID)')

def create_SampleCollectionDataTable():
    c.execute('CREATE TABLE IF NOT EXISTS sampleCollectionDataTable(sampleID TEXT PRIMARY KEY, title TEXT, nameOfDonor TEXT, cellOfDonor INTEGER, nameOfAuthorised TEXT, cellOfAuthorised INTEGER, dateReturned TEXT, destroy INTEGER, return INTEGER, FOREIGN KEY(sampleID) REFERENCES sampleInformationTable(sampleID))')

    c.execute('CREATE UNIQUE INDEX IF NOT EXISTS indexSampleID ON sampleCollectionDataTable(sampleID)')

def create_SampleInformationTable():
    c.execute('CREATE TABLE IF NOT EXISTS sampleInformationTable(sampleID TEXT PRIMARY KEY, typeOfSample TEXT, countryOfOrigin TEXT, dateOfCollection TEXT, dateOfEntry TEXT, ageOfSubject INTEGER, tubeRating INTEGER)')

    c.execute('CREATE UNIQUE INDEX IF NOT EXISTS indexSampleID ON sampleInformationTable(sampleID)')

def create_SamplePositionTable():
    c.execute('CREATE TABLE IF NOT EXISTS samplePositionTable(sampleID TEXT PRIMARY KEY, fridgeID TEXT, shelfNum INTEGER, boxNum INTEGER, xPos INTEGER, yPos INTEGER, zPos INTEGER, FOREIGN KEY(sampleID) REFERENCES sampleInformationTable(sampleID), FOREIGN KEY(fridgeID) REFERENCES fridgeTable(fridgeID))')

    c.execute('CREATE UNIQUE INDEX IF NOT EXISTS indexSampleID ON samplePositionTable(sampleID)')

create_fridgeTable()
create_SampleCollectionDataTable()
create_SampleInformationTable()
create_SamplePositionTable()




c.close()
conn.close()
