import sqlite3
import tkinter as tk
import AddFridge
import DisplayFridges
import DeleteFridge

conn = sqlite3.connect('test.db')
conn.execute("PRAGMA foreign_keys = ON")
c = conn.cursor()

#SETTING UP MAIN SCREEN----------------------------------------------------------------
window_Main = tk.Tk()

window_Main.title("MAIN FRIDGE WINDOW")
window_Main["bg"] = 'cyan'

addButton = tk.Button(window_Main, text = 'Add Fridge', command = AddFridge.OpenAddFridge).grid(row = 1, column = 1)

searchButton = tk.Button(window_Main, text = 'Display all fridges', command = DisplayFridges.OpenAllFridges).grid(row = 2, column = 1)

deleteButton = tk.Button(window_Main, text = 'Delete fridges', command = DeleteFridge.Open_DeleteFridge).grid(row = 3, column = 1)

#---------------------------------------------------------------------------------
searchField1 = tk.Entry(window_Main)
searchField1.grid(row=4,column=1)

def runDisplayFridges():
    DisplayFridges.OpenFridgeSearch(searchField1.get())
    print(searchField1.get())

searchButton1 = tk.Button(window_Main, text = 'Search for fridgeID', command = runDisplayFridges).grid(row = 4, column = 2)
#---------------------------------------------------------------------------------

#---------------------------------------------------------------------------------
searchField2 = tk.Entry(window_Main)
searchField2.grid(row=5,column=1)

def runDisplayTemperatures():
    DisplayFridges.OpenTemperatureSearch(searchField2.get())
    print(searchField2.get())

searchButton2 = tk.Button(window_Main, text = 'Search for fridge temperature', command = runDisplayTemperatures).grid(row = 5, column = 2)
#---------------------------------------------------------------------------------

#---------------------------------------------------------------------------------
searchField3 = tk.Entry(window_Main)
searchField3.grid(row=6,column=1)

def runDisplayShelves():
    DisplayFridges.OpenNumShelvesSearch(searchField3.get())
    print(searchField3.get())

searchButton3 = tk.Button(window_Main, text = 'Search for number of shelves', command = runDisplayShelves).grid(row = 6, column = 2)
#---------------------------------------------------------------------------------

window_Main.mainloop()
#----------------------------------------------------------------------------------------

c.close()
conn.close()

