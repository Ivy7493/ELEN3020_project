import sqlite3
import tkinter as tk

#def new_winF():
#    newwin = tk.Toplevel(root)
#    display = tk.Label(newwin, text = "Hmm yes")
#    display.pack()

#button1 = tk.Button(root, text = "OPEN NEW", command = new_winF)
#button1.pack()


conn = sqlite3.connect('test.db')
c = conn.cursor()

#SETTING UP MAIN SCREEN----------------------------------------------------------------
mainWindow = tk.Tk()
mainWindow.geometry("300x300")
mainWindow.title("Title of Main Window")

#SETTING UP NEW FRIDGE FORM----------------------------------------------------------------
#def UI_FridgeForm():
tk.Label(mainWindow, text = "Fridge ID").grid(row = 0)
fridgeID = tk.Entry(mainWindow)
fridgeID.grid(row = 0, column = 1)

tk.Label(mainWindow, text = "Temperature").grid(row = 1)
temp = tk.Entry(mainWindow)
temp.grid(row = 1, column = 1)

tk.Label(mainWindow, text = "Number of Shelves").grid(row = 2)
numShelves = tk.Entry(mainWindow)
numShelves.grid(row = 2, column = 1)

tk.Label(mainWindow, text = "Number of Boxes").grid(row = 3)
numBoxes = tk.Entry(mainWindow)
numBoxes.grid(row = 3, column = 1)

tk.Label(mainWindow, text = "Width of Box (X)").grid(row = 4)
boxX = tk.Entry(mainWindow)
boxX.grid(row = 4, column = 1)

tk.Label(mainWindow, text = "Length of Box (Y)").grid(row = 5)
boxY = tk.Entry(mainWindow)
boxY.grid(row = 5, column = 1)

tk.Label(mainWindow, text = "Height of Box (Z)").grid(row = 6)
boxZ = tk.Entry(mainWindow)
boxZ.grid(row = 6, column = 1)

def console_PrintFridge():
    print("Fridge ID: %s\nTemperature: %s\nNumShelves: %s\nNumBoxes: %s\nBox X: %s\nBox Y: %s\nBox Z: %s" % (fridgeID.get(), temp.get(), numShelves.get(), numBoxes.get(), boxX.get(), boxY.get(), boxZ.get()))

#END OF SETTING UP NEW FRIDGE FORM----------------------------------------------------------


def create_fridgeTable():
    c.execute('CREATE TABLE IF NOT EXISTS fridgeTable(fridgeID TEXT, temperature INTEGER, numShelves INTEGER, numBoxes INTEGER, boxX INTEGER, boxY INTEGER, boxZ INTEGER)')


def data_newFridge():

    c.execute("INSERT INTO fridgeTable (fridgeID, temperature, numShelves, numBoxes, boxX, boxY, boxZ) VALUES (?, ?, ?, ?, ?, ?, ?)",
(str(fridgeID.get()), int(temp.get()), int(numShelves.get()), int(numBoxes.get()), int(boxX.get()), int(boxY.get()), int(boxZ.get())))

    conn.commit()



tk.Button(mainWindow, text = 'Console Print', command = console_PrintFridge).grid(row = 7, column=1)
tk.Button(mainWindow, text = 'Populate', command = data_newFridge).grid(row = 8, column=1)

#c.close()
#conn.close()
mainWindow.mainloop()
#----------------------------------------------------------------------------------------

