import tkinter as tk

root = tk.Tk()

def new_winF():
    newwin = tk.Toplevel(root)
    display = tk.Label(newwin, text = "Hmm yes")
    display.pack()


button1 = tk.Button(root, text = "OPEN NEW", command = new_winF)
button1.pack()

root.mainloop()
