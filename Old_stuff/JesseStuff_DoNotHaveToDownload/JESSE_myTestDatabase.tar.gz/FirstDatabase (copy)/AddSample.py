import sqlite3
import tkinter as tk
import time
import datetime

def OpenAddSample():
    conn = sqlite3.connect('test.db')
    conn.execute("PRAGMA foreign_keys = ON")
    c = conn.cursor()

    window_AddSample = tk.Tk()
    window_AddSample.title("ADD SAMPLE")

    #SETTING UP NEW Sample FORM----------------------------------------------------------------
    tk.Label(window_AddSample, text = "Sample ID").grid(row = 0)
    sampleID = tk.Entry(window_AddSample)
    sampleID.grid(row = 0, column = 1)

    tk.Label(window_AddSample, text = "Type of Sample").grid(row = 1)
    sampleType = tk.Entry(window_AddSample)
    sampleType.grid(row = 1, column = 1)

    tk.Label(window_AddSample, text = "Country of Origin").grid(row = 2)
    originCountry = tk.Entry(window_AddSample)
    originCountry.grid(row = 2, column = 1)

    tk.Label(window_AddSample, text = "Date of Collection").grid(row = 3)
    collectionDate = tk.Entry(window_AddSample)
    collectionDate.grid(row = 3, column = 1)

    todaysDate = time.time()
    entryDate = str(datetime.datetime.fromtimestamp(todaysDate).strftime('%Y-%m-%d %H:%M%S'))

    tk.Label(window_AddSample, text = "Age of Subject").grid(row = 4)
    subjectAge = tk.Entry(window_AddSample)
    subjectAge.grid(row = 4, column = 1)

    tk.Label(window_AddSample, text = "Rating of Tube").grid(row = 5)
    tubeRating = tk.Entry(window_AddSample)
    tubeRating.grid(row = 5, column = 1)


    def data_newSample():
        c.execute("INSERT INTO sampleInformationTable (sampleID, typeOfSample, countryOfOrigin, dateOfCollection, dateOfEntry, ageOfSubject, tubeRating) VALUES (?, ?, ?, ?, ?, ?, ?)",
    (str(sampleID.get()), str(sampleType.get()), str(originCountry.get()), str(collectionDate.get()), entryDate, int(subjectAge.get()), int(tubeRating.get())))
        conn.commit()


    tk.Button(window_AddSample, text = 'Populate', command = data_newSample).grid(row = 8, column=1)


    window_AddSample.mainloop()
    c.close()
    conn.close()
    #----------------------------------------------------------------------------------------

